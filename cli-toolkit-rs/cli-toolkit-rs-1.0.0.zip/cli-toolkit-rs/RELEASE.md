# cli-toolkit-rs 1.0.0

cli-toolkit 的 Rust 单二进制 multicall 重写（uutils 风格：一个二进制、16 个 applet、argv[0] 或显式子命令分发）。

## 本版内容

- `cli-toolkit.exe`：Windows x86-64 release 二进制（Rust 1.100.0 编译，LTO + strip，约 2.6 MB，含 sysinfo）
- 16 个 applet，其中 15 个内置、1 个（`nu`）透传：
  - 内置：`toolcheck` / `hash` / `install` / `fg` / `fgr` / `fcd` / `dupes` / `big` / `disk` / `ps` / `json` / `yaml` / `replace` / `bench` / `tree`
  - 透传：`nu`（脚本运行时本身）
- 双调用方式：`cli-toolkit <applet> [args]` 与 `tb-<applet> [args]`（`cli-toolkit install <dir>` 建链接）

## 校验与安装

ZIP 的 SHA-256 固定在 `install.ps1` 的 `$PinnedZipSha['1.0.0']`；包内每个文件另由 `checksums.txt` 逐项校验。任一不符整包拒绝。

```powershell
irm https://v6.gh-proxy.org/https://raw.githubusercontent.com/zeno-ling/cli-toolkit-rs/main/cli-toolkit-rs/install.ps1 | iex
```

默认安装目录 `$env:LOCALAPPDATA\cli-toolkit-rs`，自动加入用户 PATH。卸载：`install.ps1 -Uninstall`（移除 PATH 条目，文件保留，需手动删）。

## 构建来源

```powershell
cd cli-toolkit-rs
cargo build --release
cargo test   # 47 passed
```

源码 `src/` / `Cargo.toml` 在仓库 `D:\Desktop\dsh\cli-toolkit-rs`（本地），构建产物即本包 exe。

## 实测数据

- `cargo test`：47 passed / 0 failed
- 实测 applet：`--list`（16）、`fcd --add/query/--list`、`bench cmd /c echo hi`（warmup 1 + runs 3，mean≈8ms）、`tree --depth 1`、`ps --top 3`、`disk`、`big <dir> 3`、`tb-tree` / `tb-fcd` argv[0] 模式、`install --force` 重装链接，全部符合预期。

## 已知边界

- Windows 硬链接要求同一卷；跨卷回退符号链接（可能需开发者模式/管理员）。
- 二进制更新后旧 tb-* 硬链接仍指向旧 inode，需重跑 `cli-toolkit install <dir> --force`。
- `fcd` 默认库在 `$HOME/.cli-toolkit/frecency.json`；沙箱/CI 下用 `$env:CLI_TOOLKIT_HOME` 覆盖。
- `ps`/`disk` 用 sysinfo，CPU% 是两次采样（间隔 120ms）的差值。
- 本包只含 Windows x86-64 二进制；其它平台请从源码构建。
